package ec.edu.ups.clases;

public abstract class Persona {
	//Atributos
	String nombre;
	String identificacion;
	//Metodo abstracto
	public abstract void mostrarInformacion();
}
